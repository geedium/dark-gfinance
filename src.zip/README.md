<p align="center">
  <img width="128" height="128" src="https://github.com/geedium/dark-gfinance/blob/main/icons/icon-128.png">
</p>

<h1 align="center">Dark Mode for Google Finance</h1>

Stay focused on your portfolio - not the glare. Dark mode done right.

[Get Browser Extension](https://addons.mozilla.org/en-US/firefox/addon/dark-mode-for-google-finance/)
